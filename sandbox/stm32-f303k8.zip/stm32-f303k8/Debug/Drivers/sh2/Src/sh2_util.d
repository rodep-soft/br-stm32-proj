Drivers/sh2/Src/sh2_util.o: ../Drivers/sh2/Src/sh2_util.c \
 ../Drivers/sh2/Src/../Inc/sh2_util.h
../Drivers/sh2/Src/../Inc/sh2_util.h:
