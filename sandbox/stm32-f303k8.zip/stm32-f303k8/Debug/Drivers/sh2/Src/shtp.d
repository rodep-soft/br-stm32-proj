Drivers/sh2/Src/shtp.o: ../Drivers/sh2/Src/shtp.c \
 ../Drivers/sh2/Src/../Inc/shtp.h ../Drivers/sh2/Src/../Inc/sh2_hal.h \
 ../Drivers/sh2/Src/../Inc/sh2_err.h
../Drivers/sh2/Src/../Inc/shtp.h:
../Drivers/sh2/Src/../Inc/sh2_hal.h:
../Drivers/sh2/Src/../Inc/sh2_err.h:
