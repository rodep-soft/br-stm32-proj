Drivers/sh2/Src/sh2.o: ../Drivers/sh2/Src/sh2.c \
 ../Drivers/sh2/Src/../Inc/sh2.h ../Drivers/sh2/Src/../Inc/sh2_hal.h \
 ../Drivers/sh2/Src/../Inc/sh2_err.h ../Drivers/sh2/Src/../Inc/shtp.h \
 ../Drivers/sh2/Src/../Inc/sh2_util.h
../Drivers/sh2/Src/../Inc/sh2.h:
../Drivers/sh2/Src/../Inc/sh2_hal.h:
../Drivers/sh2/Src/../Inc/sh2_err.h:
../Drivers/sh2/Src/../Inc/shtp.h:
../Drivers/sh2/Src/../Inc/sh2_util.h:
